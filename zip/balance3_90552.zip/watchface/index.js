    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //#region language (follows the watch language, English as fallback)
                const LANG_DIRS = { 2: 'en', 10: 'it', 3: 'es', 6: 'fr', 7: 'de', 15: 'pt', 20: 'pt' };
                let LG = 'lg/en/';
                try {
                  const langCode = hmSetting.getLanguage();
                  if (LANG_DIRS[langCode]) LG = 'lg/' + LANG_DIRS[langCode] + '/';
                } catch (e) {}
                //#endregion
                //#region customization: 10 accent colours, hours light tint + minutes accent (or classic white / grey)
                const ACCENTS = [[0,150,255],[255,82,82],[255,128,32],[255,190,20],[150,220,40],[0,200,120],[0,205,205],[150,110,255],[240,70,200],[200,205,215]];
                const NUM_C = ACCENTS.length;
                const REG_W = [], REG_T = [], REG_B = [];
                function loadSel(key, max) {
                  try {
                    const v = hmFS.SysProGetInt(key);
                    if (typeof v === 'number' && v >= 0 && v < max) return v;
                  } catch (e) {}
                  return 0;
                }
                let SEL_C = loadSel('gdots_color', NUM_C);
                let SEL_S = loadSel('gdots_mono', 2); // 0 = coloured time (light hours, accent minutes), 1 = classic white hours / grey minutes
                function accentColor() {
                  const a = ACCENTS[SEL_C];
                  return 0xFF000000 + a[0] * 65536 + a[1] * 256 + a[2];
                }
                function seq(prefix, from, to, suffix) {
                  const a = [];
                  for (let i = from; i <= to; i++) a.push(prefix + i + suffix);
                  return a;
                }
                function curTimeVariant() { return SEL_S === 0 ? SEL_C + 1 : 0; }
                function updateTime() {
                  for (let v = 0; v < REG_T.length; v++) REG_T[v].setProperty(hmUI.prop.VISIBLE, v === curTimeVariant());
                }
                function updateWeek() {
                  for (let k = 0; k < REG_W.length; k++) REG_W[k].setProperty(hmUI.prop.VISIBLE, k === SEL_C);
                }
                function updateBio() {
                  for (let k = 0; k < REG_B.length; k++) REG_B[k].setProperty(hmUI.prop.VISIBLE, k === SEL_C);
                }
                const NORMAL = hmUI.show_level.ONLY_NORMAL;
                const AOD = hmUI.show_level.ONLY_AOD;
                const SMALL = seq('sm_', 0, 9, '.png');
                const DATE_D = seq('dd_', 0, 9, '.png');
                const HOURS = seq('hw_', 0, 9, '.png');
                const MINS_GREY = seq('hg_', 0, 9, '.png');
                function timeWidget(hourArr, minuteArr, level) {
                  return hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_startX: 68, hour_startY: 160, hour_array: hourArr, hour_zero: 1, hour_space: 0, hour_angle: 0, hour_align: hmUI.align.LEFT,
                    minute_startX: 252, minute_startY: 160, minute_array: minuteArr, minute_zero: 1, minute_space: 0, minute_angle: 0, minute_follow: 0, minute_align: hmUI.align.LEFT,
                    show_level: level,
                  });
                }
                //#endregion

                //#region normal screen
                console.log('Watch_Face.ScreenNormal');
                hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 480, h: 480, src: 'bg.png', show_level: NORMAL });
                const screenType = hmSetting.getScreenType();

                // weather: icon + temperature
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 190, y: 30, image_array: seq('wi_', 0, 28, '.png'), image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT, show_level: NORMAL,
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 244, y: 35, font_array: SMALL, padding: false, h_space: 0,
                  unit_sc: 'deg.png', unit_tc: 'deg.png', unit_en: 'deg.png', negative_image: 'minus.png',
                  align_h: hmUI.align.LEFT, type: hmUI.data_type.WEATHER_CURRENT, show_level: NORMAL,
                });

                // date dd.mm.yyyy
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                  day_startX: 171, day_startY: 74, day_sc_array: DATE_D, day_tc_array: DATE_D, day_en_array: DATE_D,
                  day_zero: 1, day_space: 0, day_align: hmUI.align.CENTER_H, day_is_character: false, show_level: NORMAL,
                });
                hmUI.createWidget(hmUI.widget.IMG, { x: 201, y: 71, src: 'dot.png', show_level: NORMAL });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                  month_startX: 210, month_startY: 74, month_sc_array: DATE_D, month_tc_array: DATE_D, month_en_array: DATE_D,
                  month_zero: 1, month_space: 0, month_align: hmUI.align.CENTER_H, month_is_character: false, show_level: NORMAL,
                });
                hmUI.createWidget(hmUI.widget.IMG, { x: 241, y: 71, src: 'dot.png', show_level: NORMAL });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                  year_startX: 250, year_startY: 74, year_sc_array: DATE_D, year_tc_array: DATE_D, year_en_array: DATE_D,
                  year_zero: 1, year_space: 0, year_align: hmUI.align.CENTER_H, year_is_character: false, show_level: NORMAL,
                });

                // weekday strip in the watch language, the highlighted day follows the accent colour (one copy per colour)
                for (let k = 0; k < NUM_C; k++) {
                  const arr = seq(LG + 'wk' + k + '_', 0, 6, '.png');
                  const w = hmUI.createWidget(hmUI.widget.IMG_WEEK, { x: 56, y: 106, week_en: arr, week_tc: arr, week_sc: arr, show_level: NORMAL });
                  w.setProperty(hmUI.prop.VISIBLE, k === SEL_C);
                  REG_W.push(w);
                }

                // time: variant 0 = white hours / grey minutes, variants 1..10 = light-tinted hours + accent minutes
                for (let v = 0; v < NUM_C + 1; v++) {
                  const hArr = v === 0 ? HOURS : seq('hl' + (v - 1) + '_', 0, 9, '.png');
                  const mArr = v === 0 ? MINS_GREY : seq('ht' + (v - 1) + '_', 0, 9, '.png');
                  const tw = timeWidget(hArr, mArr, NORMAL);
                  tw.setProperty(hmUI.prop.VISIBLE, v === curTimeVariant());
                  REG_T.push(tw);
                }

                // heart rate (left) and calories (right), one centred row
                hmUI.createWidget(hmUI.widget.IMG, { x: 112, y: 292, src: 'ic_hr.png', show_level: NORMAL });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 164, y: 297, w: 68, font_array: SMALL, padding: false, h_space: 0,
                  align_h: hmUI.align.CENTER_H, type: hmUI.data_type.HEART, show_level: NORMAL,
                });
                hmUI.createWidget(hmUI.widget.IMG, { x: 248, y: 290, src: 'ic_cal.png', show_level: NORMAL });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 300, y: 297, w: 68, font_array: SMALL, padding: false, h_space: 0,
                  align_h: hmUI.align.CENTER_H, type: hmUI.data_type.CAL, show_level: NORMAL,
                });

                // three gauges: battery, steps, HybridCharge
                const GAUGES = [
                  { cx: 137, id: 'BATTERY' },
                  { cx: 240, id: 'STEP' },
                  { cx: 343, id: 'BIO_CHARGE' },
                ];
                const GY = 384;
                const arcs = [];
                for (let g = 0; g < 2; g++) {
                  arcs.push(hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: GAUGES[g].cx, center_y: GY, start_angle: 0, end_angle: 360, radius: 44, line_width: 7, corner_flag: 0,
                    color: accentColor(), show_level: NORMAL,
                  }));
                }
                // HybridCharge ring: 20 level images per colour, only the selected colour is visible
                for (let k = 0; k < NUM_C; k++) {
                  const w = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: GAUGES[2].cx - 48, y: GY - 48, image_array: seq('bio' + k + '_', 0, 19, '.png'), image_length: 20,
                    type: hmUI.data_type.BIO_CHARGE, show_level: NORMAL,
                  });
                  w.setProperty(hmUI.prop.VISIBLE, k === SEL_C);
                  REG_B.push(w);
                }
                hmUI.createWidget(hmUI.widget.IMG, { x: 113, y: 346, src: 'ic_bat.png', show_level: NORMAL });
                hmUI.createWidget(hmUI.widget.IMG, { x: 216, y: 344, src: 'ic_step.png', show_level: NORMAL });
                hmUI.createWidget(hmUI.widget.IMG, { x: 319, y: 344, src: 'ic_bio.png', show_level: NORMAL });
                for (let g = 0; g < GAUGES.length; g++) {
                  hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: GAUGES[g].cx - 40, y: 390, w: 80, font_array: SMALL, padding: false, h_space: -2,
                    align_h: hmUI.align.CENTER_H, type: hmUI.data_type[GAUGES[g].id], show_level: NORMAL,
                  });
                }
                const sensBattery = hmSensor.createSensor(hmSensor.id.BATTERY);
                const sensStep = hmSensor.createSensor(hmSensor.id.STEP);
                function arcLevel(cur, target) {
                  let p = target ? cur / target : 0;
                  if (!(p > 0)) p = 0;
                  if (p > 1) p = 1;
                  return Math.round(p * 100);
                }
                function scaleCall() {
                  if (screenType === hmSetting.screen_type.AOD) return;
                  const levels = [arcLevel(sensBattery.current, 100), arcLevel(sensStep.current, sensStep.target)];
                  for (let g = 0; g < arcs.length; g++) {
                    arcs[g].setProperty(hmUI.prop.MORE, {
                      center_x: GAUGES[g].cx, center_y: GY, start_angle: 0, end_angle: 360, radius: 44, line_width: 7, corner_flag: 0,
                      color: accentColor(), show_level: NORMAL, level: levels[g],
                    });
                  }
                }
                try {
                  sensBattery.addEventListener(hmSensor.event.CHANGE, scaleCall);
                  sensStep.addEventListener(hmSensor.event.CHANGE, scaleCall);
                } catch (e) {}
                scaleCall();

                // jump zones to the native screens
                const zone = function (x, y, w, h, type) {
                  hmUI.createWidget(hmUI.widget.IMG_CLICK, { x: x, y: y, w: w, h: h, type: type, show_level: NORMAL });
                };
                zone(170, 26, 150, 46, hmUI.data_type.WEATHER_CURRENT);
                zone(68, 160, 160, 122, hmUI.data_type.COUNT_DOWN);    // hours
                zone(252, 160, 160, 122, hmUI.data_type.STOP_WATCH);   // minutes
                zone(108, 288, 128, 44, hmUI.data_type.HEART);
                zone(244, 288, 128, 44, hmUI.data_type.CAL);
                zone(194, 338, 92, 92, hmUI.data_type.STEP);
                zone(297, 338, 92, 92, hmUI.data_type.BIO_CHARGE);

                // tap the weekday strip -> next accent colour
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 56, y: 106, w: 368, h: 45, text: '', color: 0xFFFFFFFF, text_size: 20,
                  press_src: 'empty.png', normal_src: 'empty.png',
                  click_func: () => {
                    SEL_C = (SEL_C + 1) % NUM_C;
                    updateWeek();
                    updateBio();
                    updateTime();
                    scaleCall();
                    try { hmFS.SysProSetInt('gdots_color', SEL_C); } catch (e) {}
                  },
                  show_level: NORMAL,
                });
                // tap the date -> coloured time / classic white + grey time
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 160, y: 68, w: 170, h: 36, text: '', color: 0xFFFFFFFF, text_size: 20,
                  press_src: 'empty.png', normal_src: 'empty.png',
                  click_func: () => {
                    SEL_S = SEL_S === 0 ? 1 : 0;
                    updateTime();
                    try { hmFS.SysProSetInt('gdots_mono', SEL_S); } catch (e) {}
                  },
                  show_level: NORMAL,
                });

                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                  resume_call: (function () { scaleCall(); }),
                });
                //#endregion

                //#region always-on display
                console.log('Watch_Face.ScreenAOD');
                hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 480, h: 480, src: 'aod.png', show_level: AOD });
                timeWidget(HOURS, MINS_GREY, AOD);
                //#endregion
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}