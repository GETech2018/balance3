﻿    /*
    ** Watch_Face_Editor tool v 18.2
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let normal_image_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let normal_bio_charge_text_text_img = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 34;
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 38;
        let normal_heart_rate_TextCircle_img_height = 39;
        let normal_battery_icon_img = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 38;
        let normal_battery_TextCircle_img_height = 39;
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_digital_clock_img_time = ''
        let idle_bio_charge_text_text_img = ''
        let idle_step_TextRotate = new Array(5);
        let idle_step_TextRotate_ASCIIARRAY = new Array(10);
        let idle_step_TextRotate_img_width = 34;
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_TextCircle = new Array(3);
        let idle_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextCircle_img_width = 38;
        let idle_heart_rate_TextCircle_img_height = 39;
        let idle_battery_icon_img = ''
        let idle_battery_TextCircle = new Array(3);
        let idle_battery_TextCircle_ASCIIARRAY = new Array(10);
        let idle_battery_TextCircle_img_width = 38;
        let idle_battery_TextCircle_img_height = 39;
        let image_top_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background_66c1cc5b.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'pointers_second_custom_icons_custom_icon_1792782040776_B2FC5D64.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'pointers_second_custom_icons_custom_icon_1792782040776_B2FC5D64.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              fresh_frequency: 30,
              fresh_freqency: 30,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 30,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 15,
              src: 'background_66c1cc5b.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'pointers_second_custom_icons_custom_icon_1792784470197_DD3D459A.png',
              second_centerX: 240,
              second_centerY: 316,
              second_posX: 10,
              second_posY: 10,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 85,
              hour_startY: 360,
              hour_array: ["chars_1CF65FA3_000.png","chars_1CF65FA3_001.png","chars_1CF65FA3_002.png","chars_1CF65FA3_003.png","chars_1CF65FA3_004.png","chars_1CF65FA3_005.png","chars_1CF65FA3_006.png","chars_1CF65FA3_007.png","chars_1CF65FA3_008.png","chars_1CF65FA3_009.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 248,
              minute_startY: 357,
              minute_array: ["chars_7D2547FC_000.png","chars_7D2547FC_001.png","chars_7D2547FC_002.png","chars_7D2547FC_003.png","chars_7D2547FC_004.png","chars_7D2547FC_005.png","chars_7D2547FC_006.png","chars_7D2547FC_007.png","chars_7D2547FC_008.png","chars_7D2547FC_009.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 196,
              second_startY: 435,
              second_array: ["chars_518F64A0_000.png","chars_518F64A0_001.png","chars_518F64A0_002.png","chars_518F64A0_003.png","chars_518F64A0_004.png","chars_518F64A0_005.png","chars_518F64A0_006.png","chars_518F64A0_007.png","chars_518F64A0_008.png","chars_518F64A0_009.png"],
              second_zero: 1,
              second_space: -8,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 351,
              y: 298,
              font_array: ["chars_76635899_000.png","chars_76635899_001.png","chars_76635899_002.png","chars_76635899_003.png","chars_76635899_004.png","chars_76635899_005.png","chars_76635899_006.png","chars_76635899_007.png","chars_76635899_008.png","chars_76635899_009.png"],
              padding: false,
              h_space: -8,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 19,
              // y: 351,
              // font_array: ["chars_76635899_000.png","chars_76635899_001.png","chars_76635899_002.png","chars_76635899_003.png","chars_76635899_004.png","chars_76635899_005.png","chars_76635899_006.png","chars_76635899_007.png","chars_76635899_008.png","chars_76635899_009.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -12,
              // angle: 324,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'chars_76635899_000.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'chars_76635899_001.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'chars_76635899_002.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'chars_76635899_003.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'chars_76635899_004.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'chars_76635899_005.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'chars_76635899_006.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'chars_76635899_007.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'chars_76635899_008.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'chars_76635899_009.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 19,
                center_y: 351,
                pos_x: 19,
                pos_y: 351,
                angle: 324,
                src: 'chars_76635899_000.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 356,
              y: 86,
              src: 'heart_4_25x25.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["chars_3BD28E34_000.png","chars_3BD28E34_001.png","chars_3BD28E34_002.png","chars_3BD28E34_003.png","chars_3BD28E34_004.png","chars_3BD28E34_005.png","chars_3BD28E34_006.png","chars_3BD28E34_007.png","chars_3BD28E34_008.png","chars_3BD28E34_009.png"],
              // radius: 169,
              // angle: 33,
              // char_space_angle: -5,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'chars_3BD28E34_000.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'chars_3BD28E34_001.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'chars_3BD28E34_002.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'chars_3BD28E34_003.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'chars_3BD28E34_004.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'chars_3BD28E34_005.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'chars_3BD28E34_006.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'chars_3BD28E34_007.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'chars_3BD28E34_008.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'chars_3BD28E34_009.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 - 208,
                src: 'chars_3BD28E34_000.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 102,
              y: 80,
              src: 'custom_icon_1792596493994_1792597186470_25x25.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["chars_3BD28E34_000.png","chars_3BD28E34_001.png","chars_3BD28E34_002.png","chars_3BD28E34_003.png","chars_3BD28E34_004.png","chars_3BD28E34_005.png","chars_3BD28E34_006.png","chars_3BD28E34_007.png","chars_3BD28E34_008.png","chars_3BD28E34_009.png"],
              // radius: 170,
              // angle: -31,
              // char_space_angle: -3,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'chars_3BD28E34_000.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'chars_3BD28E34_001.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'chars_3BD28E34_002.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'chars_3BD28E34_003.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'chars_3BD28E34_004.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'chars_3BD28E34_005.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'chars_3BD28E34_006.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'chars_3BD28E34_007.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'chars_3BD28E34_008.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'chars_3BD28E34_009.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_battery_TextCircle_img_width / 2,
                pos_y: 240 - 209,
                src: 'chars_3BD28E34_000.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 15,
              src: 'background_ad3ecd0e.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 85,
              hour_startY: 360,
              hour_array: ["chars_1CF65FA3_000.png","chars_1CF65FA3_001.png","chars_1CF65FA3_002.png","chars_1CF65FA3_003.png","chars_1CF65FA3_004.png","chars_1CF65FA3_005.png","chars_1CF65FA3_006.png","chars_1CF65FA3_007.png","chars_1CF65FA3_008.png","chars_1CF65FA3_009.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 248,
              minute_startY: 357,
              minute_array: ["chars_7D2547FC_000.png","chars_7D2547FC_001.png","chars_7D2547FC_002.png","chars_7D2547FC_003.png","chars_7D2547FC_004.png","chars_7D2547FC_005.png","chars_7D2547FC_006.png","chars_7D2547FC_007.png","chars_7D2547FC_008.png","chars_7D2547FC_009.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 196,
              second_startY: 435,
              second_array: ["chars_518F64A0_000.png","chars_518F64A0_001.png","chars_518F64A0_002.png","chars_518F64A0_003.png","chars_518F64A0_004.png","chars_518F64A0_005.png","chars_518F64A0_006.png","chars_518F64A0_007.png","chars_518F64A0_008.png","chars_518F64A0_009.png"],
              second_zero: 1,
              second_space: -8,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 351,
              y: 298,
              font_array: ["chars_76635899_000.png","chars_76635899_001.png","chars_76635899_002.png","chars_76635899_003.png","chars_76635899_004.png","chars_76635899_005.png","chars_76635899_006.png","chars_76635899_007.png","chars_76635899_008.png","chars_76635899_009.png"],
              padding: false,
              h_space: -8,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 19,
              // y: 351,
              // font_array: ["chars_76635899_000.png","chars_76635899_001.png","chars_76635899_002.png","chars_76635899_003.png","chars_76635899_004.png","chars_76635899_005.png","chars_76635899_006.png","chars_76635899_007.png","chars_76635899_008.png","chars_76635899_009.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -12,
              // angle: 324,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextRotate_ASCIIARRAY[0] = 'chars_76635899_000.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[1] = 'chars_76635899_001.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[2] = 'chars_76635899_002.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[3] = 'chars_76635899_003.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[4] = 'chars_76635899_004.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[5] = 'chars_76635899_005.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[6] = 'chars_76635899_006.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[7] = 'chars_76635899_007.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[8] = 'chars_76635899_008.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[9] = 'chars_76635899_009.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              idle_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 19,
                center_y: 351,
                pos_x: 19,
                pos_y: 351,
                angle: 324,
                src: 'chars_76635899_000.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 356,
              y: 86,
              src: 'heart_4_25x25.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["chars_3BD28E34_000.png","chars_3BD28E34_001.png","chars_3BD28E34_002.png","chars_3BD28E34_003.png","chars_3BD28E34_004.png","chars_3BD28E34_005.png","chars_3BD28E34_006.png","chars_3BD28E34_007.png","chars_3BD28E34_008.png","chars_3BD28E34_009.png"],
              // radius: 169,
              // angle: 33,
              // char_space_angle: -5,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextCircle_ASCIIARRAY[0] = 'chars_3BD28E34_000.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[1] = 'chars_3BD28E34_001.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[2] = 'chars_3BD28E34_002.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[3] = 'chars_3BD28E34_003.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[4] = 'chars_3BD28E34_004.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[5] = 'chars_3BD28E34_005.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[6] = 'chars_3BD28E34_006.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[7] = 'chars_3BD28E34_007.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[8] = 'chars_3BD28E34_008.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[9] = 'chars_3BD28E34_009.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 - 208,
                src: 'chars_3BD28E34_000.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 102,
              y: 80,
              src: 'custom_icon_1792596493994_1792597186470_25x25.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["chars_3BD28E34_000.png","chars_3BD28E34_001.png","chars_3BD28E34_002.png","chars_3BD28E34_003.png","chars_3BD28E34_004.png","chars_3BD28E34_005.png","chars_3BD28E34_006.png","chars_3BD28E34_007.png","chars_3BD28E34_008.png","chars_3BD28E34_009.png"],
              // radius: 170,
              // angle: -31,
              // char_space_angle: -3,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextCircle_ASCIIARRAY[0] = 'chars_3BD28E34_000.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[1] = 'chars_3BD28E34_001.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[2] = 'chars_3BD28E34_002.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[3] = 'chars_3BD28E34_003.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[4] = 'chars_3BD28E34_004.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[5] = 'chars_3BD28E34_005.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[6] = 'chars_3BD28E34_006.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[7] = 'chars_3BD28E34_007.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[8] = 'chars_3BD28E34_008.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[9] = 'chars_3BD28E34_009.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              idle_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_battery_TextCircle_img_width / 2,
                pos_y: 240 - 209,
                src: 'chars_3BD28E34_000.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 208,
              y: 130,
              src: 'pointers_second_custom_icons_custom_icon_1792783936136_6370C1EC.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 19 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + -12;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 33;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 169));
                  // alignment = RIGHT
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_angleOffset + -5 * (normal_heart_rate_circle_string.length - 1) / 2;
                  char_Angle -= 2 * normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_heart_rate_TextCircle_img_angle + -5;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -31;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 170));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_battery_TextCircle_img_angle + -3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let idle_step_rotate_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_rotate_string.length > 0 && idle_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 19 + img_offset);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.SRC, idle_step_TextRotate_ASCIIARRAY[charCode]);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_step_TextRotate_img_width + -12;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let idle_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 33;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_circle_string.length > 0 && idle_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let idle_heart_rate_TextCircle_img_angle = 0;
                  let idle_heart_rate_TextCircle_dot_img_angle = 0;
                  idle_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(idle_heart_rate_TextCircle_img_width/2, 169));
                  // alignment = RIGHT
                  let idle_heart_rate_TextCircle_angleOffset = idle_heart_rate_TextCircle_img_angle * (idle_heart_rate_circle_string.length - 1);
                  idle_heart_rate_TextCircle_angleOffset = idle_heart_rate_TextCircle_angleOffset + -5 * (idle_heart_rate_circle_string.length - 1) / 2;
                  char_Angle -= 2 * idle_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_heart_rate_TextCircle_img_width / 2);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_heart_rate_TextCircle_img_angle + -5;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle battery_BATTERY');
              let idle_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -31;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_circle_string.length > 0 && idle_battery_circle_string.length <= 3) {  // display data if it was possible to get it
                  let idle_battery_TextCircle_img_angle = 0;
                  let idle_battery_TextCircle_dot_img_angle = 0;
                  idle_battery_TextCircle_img_angle = toDegree(Math.atan2(idle_battery_TextCircle_img_width/2, 170));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_battery_TextCircle_img_width / 2);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.SRC, idle_battery_TextCircle_ASCIIARRAY[charCode]);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_battery_TextCircle_img_angle + -3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}